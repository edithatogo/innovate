from .base import DiffusionModel, Self
