from .categorization import categorize_adopters
